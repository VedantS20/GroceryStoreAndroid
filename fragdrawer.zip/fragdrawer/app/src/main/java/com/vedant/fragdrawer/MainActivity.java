package com.vedant.fragdrawer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener,fruitfrag.FragmentFruitListener {
    private DrawerLayout drawerLayout;
    BottomNavigationView bottomNavigationView;
    private fruitfrag Fruitfrag;
    private cartfrag Cartfrag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        LinearLayout linearLayout = findViewById(R.id.llayout);
        View v1= inflater.inflate(R.layout.nev_list,null);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawerLayout = findViewById(R.id.drawer_layout);
        TextView name = v1.findViewById(R.id.profilename);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar, R.string.Navigation_drawer_open ,R.string.Navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        bottomNavigationView = findViewById(R.id.bottom_nev);
        bottomNavigationView.setOnNavigationItemSelectedListener(navlistener);
        Fruitfrag = new fruitfrag();
        Cartfrag = new cartfrag();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment,Fruitfrag).commit();
    }
    private BottomNavigationView.OnNavigationItemSelectedListener navlistener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment selectefrag = null;
            switch (item.getItemId())
            {
                case R.id.vegi:
                    selectefrag = new vegefrag();
                    //getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new vegefrag()).commit();
                    break;
                case R.id.fruits:
                    selectefrag = Fruitfrag;
                    // getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new fruitfrag()).commit();
                    break;
                case R.id.dairy:
                    selectefrag = new dairyfrag();
                    //getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new dairyfrag()).commit();
                    break;
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment , selectefrag).commit();
            return true;
        }
    };
    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.vegi:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new vegefrag()).commit();
                break;
            case R.id.fruits:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment,Fruitfrag).commit();
                break;
            case R.id.dairy:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new dairyfrag()).commit();
                break;
            case R.id.cart:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment,Cartfrag).commit();
                break;
            case R.id.settings:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new settingsfrag()).commit();
                break;
            case R.id.help:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new helpfrag()).commit();
                break;
            case R.id.profile:
                Intent intent2 = getIntent();
                User user = (User) intent2.getSerializableExtra("User");
                Intent intent = new Intent(MainActivity.this , profile.class);
                intent.putExtra("User1" , user);
                intent.putExtra("Name" , user.getName());
                intent.putExtra("Pass" , user.getPassword());
                startActivity(intent);
                //getSupportFragmentManager().beginTransaction().replace(R.id.fragment,new prof()).commit();
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void OnInputSent(CharSequence guva,CharSequence melon,CharSequence orange,CharSequence pine) {
        Cartfrag.UpdateText(guva ,melon ,orange,pine);
    }

}