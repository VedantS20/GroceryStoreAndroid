package com.vedant.fragdrawer;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class fruitfrag extends Fragment {
    public EditText GuvaCount , MelonCount , PineCount,OrangeCount;
    public Button Ok;
    public FragmentFruitListener fragmentFruitListener;
    public interface FragmentFruitListener{
        void OnInputSent(CharSequence guva,CharSequence melon,CharSequence orange,CharSequence pine);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fruit,container,false);
    GuvaCount =view.findViewById(R.id.guvacount);
    MelonCount=view.findViewById(R.id.meloncount);
    PineCount = view.findViewById(R.id.pinecount);
    OrangeCount = view.findViewById(R.id.orangecount);
    Ok = view.findViewById(R.id.ok);
    Ok.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            CharSequence Guva =GuvaCount.getText();
            CharSequence Melon =MelonCount.getText();
            CharSequence Pine =PineCount.getText();
            CharSequence Orange =OrangeCount.getText();
            fragmentFruitListener.OnInputSent(Guva,Melon,Orange,Pine);
        }
    });
        return view;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof FragmentFruitListener)
        {
            fragmentFruitListener = (FragmentFruitListener) context;
        }
        else {
            throw new RuntimeException(context.toString()
                    + "Must Implement FragmentFruitListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        fragmentFruitListener=null;
    }
}
