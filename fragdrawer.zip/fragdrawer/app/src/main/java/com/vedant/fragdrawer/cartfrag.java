package com.vedant.fragdrawer;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class cartfrag extends Fragment {
     public EditText Guva , Melon , Pine,Orange;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.fragment_cart,container,false);
        Guva = v.findViewById(R.id.guvacart);
        Melon = v.findViewById(R.id.meloncart);
        Pine = v.findViewById(R.id.pinecart);
        Orange = v.findViewById(R.id.orangecart);
        return v;
    }
    public void UpdateText(CharSequence guva,CharSequence melon,CharSequence pine,CharSequence orange){
       Guva.setText(guva);
        Melon.setText(melon);
        Pine.setText(pine);
        Orange.setText(orange);
    }
}
